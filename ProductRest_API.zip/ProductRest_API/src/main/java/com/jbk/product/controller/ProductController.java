package com.jbk.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jbk.product.entity.Product;
import com.jbk.product.model.FinalProduct;
import com.jbk.product.service.ProductService;

@RestController
@RequestMapping(value = "/product")
public class ProductController {

	@Autowired
	private ProductService productService;

	@PostMapping(value = "/save-product")
	public ResponseEntity<Boolean> saveProduct(@RequestBody Product product) {
		boolean isAdded = productService.saveProduct(product);
		if (isAdded) {

			return new ResponseEntity<Boolean>(isAdded, HttpStatus.CREATED);
		} else {

			return new ResponseEntity<Boolean>(isAdded, HttpStatus.OK);
		}

	}

	@GetMapping(value = "/get-product-by-id/{productId}")
	public ResponseEntity<Product> getProductById(@PathVariable long productId) {
		Product product = productService.getProductById(productId);

		if (product != null) {

			return new ResponseEntity<Product>(product, HttpStatus.OK);
		} else {

			return new ResponseEntity<Product>(HttpStatus.NO_CONTENT);
		}

	}

	@GetMapping(value = "/get-all-products")
	public ResponseEntity<List<Product>> getAllProducts() {

		List<Product> products = productService.getAllProducts();
		if (products != null) {

			return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
		} else {

			return new ResponseEntity<List<Product>>(products, HttpStatus.NO_CONTENT);
		}

	}

	@DeleteMapping(value = "/delete-product-by-id/{productId}")
	public ResponseEntity<Boolean> deleteProductById(@PathVariable long productId) {
		boolean isDeleted = productService.deleteProductById(productId);
		if (isDeleted) {

			return new ResponseEntity<Boolean>(isDeleted, HttpStatus.OK);
		} else {

			return new ResponseEntity<Boolean>(isDeleted, HttpStatus.NO_CONTENT);
		}

	}

	@PutMapping(value = "/upadte-product")
	public ResponseEntity<Boolean> updateProduct(@RequestBody Product product) {
		boolean isUpdate = productService.updateProduct(product);
		if (isUpdate) {

			return new ResponseEntity<Boolean>(isUpdate, HttpStatus.OK);
		} else {
			return new ResponseEntity<Boolean>(isUpdate, HttpStatus.NO_CONTENT);
		}
	}

	@GetMapping(value = "/get-product-by-id_ASC")
	public ResponseEntity<List<Product>> sortProductsById_ASC() {
		List<Product> products = productService.sortProductsById_ASC();
		if (products != null) {

			return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
		} else {

			return new ResponseEntity<List<Product>>(products, HttpStatus.NO_CONTENT);
		}

	}

	@GetMapping(value = "/get-product-by-name_DESC")
	public ResponseEntity<List<Product>> sortProductsByName_DESC() {
		List<Product> products = productService.sortProductsByName_DESC();
		if (products != null) {

			return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
		} else {

			return new ResponseEntity<List<Product>>(products, HttpStatus.NO_CONTENT);
		}

	}

	@GetMapping(value = "/get-max-price-products")
	public ResponseEntity<List<Product>> getMaxPriceProducts() {

		List<Product> list = productService.getMaxPriceProducts();
		if (list != null) {
			return new ResponseEntity<List<Product>>(list, HttpStatus.OK);
		} else {

			return new ResponseEntity<List<Product>>(list, HttpStatus.NO_CONTENT);
		}

	}

	@GetMapping(value = "/sum-of-product-price")
	public ResponseEntity<Double> countSumOfProductPrice() {
		double sum = productService.countSumOfProductPrice();

		return new ResponseEntity<Double>(sum, HttpStatus.OK);

	}

	@GetMapping(value = "/get-total-count-of-products")
	public ResponseEntity<Integer> getTotalCountOfProducts() {
		int count = productService.getTotalCountOfProducts();

		return new ResponseEntity<Integer>(count, HttpStatus.OK);

	}
	
	@GetMapping(value = "/get-finalproduct-by-id/{productId}")
	public ResponseEntity<FinalProduct> getFinalProductById(@PathVariable long productId)
	{
		FinalProduct finalProduct = productService.getFinalProductById(productId);
		if(finalProduct!=null) {
			
			return new ResponseEntity<FinalProduct>(finalProduct, HttpStatus.OK);
		}
		else {
			return new ResponseEntity<FinalProduct>(finalProduct, HttpStatus.NO_CONTENT);
		}
		
	}

}
