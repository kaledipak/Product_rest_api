package com.jbk.product.daoIMPL;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jbk.product.dao.CategoryDao;
import com.jbk.product.entity.Category;

@Repository
public class CategoryDaoIMPL implements CategoryDao {

	@Autowired
	private SessionFactory factory;

	@Override
	public boolean saveCategory(Category category) {

		Session session = factory.openSession();

		Transaction trans = session.beginTransaction();
		boolean isAdded = false;

		try {

			Category dbCategory = session.get(Category.class, category.getCategoryId());
			if (dbCategory == null) {
				session.save(category);
				trans.commit();
				isAdded = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			if (session != null) {

				session.close();
			}

		}

		return isAdded;
	}

	@Override
	public Category getCategoryById(long categoryId) {

		Session session = factory.openSession();
		Category category = null;
		try {
			category = session.get(Category.class, categoryId);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			if (session != null) {

				session.close();
			}
		}

		return category;
	}

	@Override
	public Category getCategoryByName(String categoryName) {

		Session session = factory.openSession();

		Category category = null;
		try {
			@SuppressWarnings("deprecation")
			Criteria criteria = session.createCriteria(Category.class);
			criteria.add(Restrictions.eq("categoryName", categoryName));
			category = (Category) criteria.uniqueResult();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (session != null) {

				session.close();
			}
		}

		return category;
	}

}
