package com.jbk.product.serviceIMPL;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jbk.product.dao.SupplierDao;
import com.jbk.product.entity.Supplier;
import com.jbk.product.service.SupplierService;

  

@Service
public class SupplierServiceIMPL implements SupplierService {

	@Autowired
	
	private SupplierDao supplierDao;
	
	@Override
	public boolean saveSupplier(Supplier supplier) {
		
		return supplierDao.saveSupplier(supplier);
	}

	@Override
	public Supplier getSupplierById(long supplierId) {
		
		return supplierDao.getSupplierById(supplierId);
	}

	@Override
	public Supplier getSupplierByName(String supplierName) {
		
		return supplierDao.getSupplierByName(supplierName);
	}

}
