package com.jbk.product.serviceIMPL;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.jbk.product.dao.ProductDao;
import com.jbk.product.entity.Product;
import com.jbk.product.model.Charges;
import com.jbk.product.model.FinalProduct;
import com.jbk.product.service.ProductService;

@Service
public class ProductServiceIMPL implements ProductService {

	@Autowired
	private ProductDao productDao;

	@Override
	public boolean saveProduct(Product product) {

		return productDao.saveProduct(product);
	}

	@Override
	@Cacheable(cacheNames = "Products" , key = "#productId")
	public Product getProductById(long productId) {

		return productDao.getProductById(productId);
	}

	@Override
	public List<Product> getAllProducts() {

		return productDao.getAllProducts();
	}

	@Override
	//@CacheEvict(cacheNames = "Products",key = "#productId")
	//above annotation gives exception because of method type
	//need to change method type to Product
	public boolean deleteProductById(long productId) {

		return productDao.deleteProductById(productId);
	}

	@Override
	//@CachePut(cacheNames = "Products" , key = "#product.productId")
	//above annotation gives exception because of method type
	//need to change method type to Product
	public boolean updateProduct(Product product) {

		return productDao.updateProduct(product);
	}

	@Override
	public List<Product> sortProductsById_ASC() {

		return productDao.sortProductsById_ASC();
	}

	@Override
	public List<Product> sortProductsByName_DESC() {

		return productDao.sortProductsByName_DESC();
	}

	@Override
	public List<Product> getMaxPriceProducts() {

		return productDao.getMaxPriceProducts();
	}

	@Override
	public double countSumOfProductPrice() {

		return productDao.countSumOfProductPrice();
	}

	@Override
	public int getTotalCountOfProducts() {

		return productDao.getTotalCountOfProducts();
	}

	@Override
	public String importSheet() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String exportSheet() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FinalProduct getFinalProductById(long productId) {

		Product product = productDao.getProductById(productId);

		Charges charges = new Charges();
		
	    charges.setGst(product.getProductPrice() * product.getCategory().getGst() / 100);
		charges.setDeliveryCharge(product.getCategory().getDeliveryCharge());

		FinalProduct finalProduct = new FinalProduct();
		
		double discountAmount = (product.getProductPrice() * product.getCategory().getDiscount() / 100);
		double gstAmount = (product.getProductPrice()*product.getCategory().getGst()/100);
        double finalPrice = (product.getProductPrice() + gstAmount
				+ product.getCategory().getDeliveryCharge() - discountAmount);
		
		finalProduct.setProductId(productId);
		finalProduct.setProductName(product.getProductName());
		finalProduct.setCategory(product.getCategory());
		finalProduct.setSupplier(product.getSupplier());
		finalProduct.setProductQYT(product.getProductQYT());
		finalProduct.setProductPrice(product.getProductPrice());
		finalProduct.setCharges(charges);
		finalProduct.setDiscountAmount(discountAmount);
		finalProduct.setFinalAmount(finalPrice);

		return finalProduct;
	}

}
